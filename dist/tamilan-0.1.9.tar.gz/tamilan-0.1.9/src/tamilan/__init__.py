# __init__.py
# from .twosum import twoSum, twoSumK, is_subsequence, AI, Bot
from .chatbot import AI, Bot
from .functions import twoSumK, twoSum, is_subsequence
