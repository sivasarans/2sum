# __init__.py
from .twosum import twoSum, twoSumK, is_subsequence, AI
